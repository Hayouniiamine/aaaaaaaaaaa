<template>
  <div class="page-support">
    <div class="support-hero">
      <h1>Support TikTak PRO</h1>
      <p>Notre assistant IA est disponible 24/7. Cliquez sur le bouton ✦ en bas à droite.</p>
    </div>
  </div>
</template>

<style scoped>
.page-support {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f8fafc;
  font-family: 'Plus Jakarta Sans', sans-serif;
}
.support-hero {
  text-align: center;
  padding: 40px;
}
.support-hero h1 {
  font-size: 28px;
  font-weight: 800;
  color: #0f172a;
  margin: 0 0 8px;
}
.support-hero p {
  font-size: 15px;
  color: #64748b;
  margin: 0;
}
</style>

