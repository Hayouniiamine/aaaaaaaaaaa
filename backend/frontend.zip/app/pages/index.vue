<template>
  <div class="page-home">
    <div class="hero">
      <h1>TikTak PRO</h1>
      <p>Plateforme e-commerce — Cliquez sur le bouton en bas à droite pour ouvrir l'assistant IA.</p>
    </div>
  </div>
</template>

<style scoped>
.page-home {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f8fafc;
  font-family: 'Plus Jakarta Sans', sans-serif;
}
.hero {
  text-align: center;
  padding: 40px;
}
.hero h1 {
  font-size: 32px;
  font-weight: 800;
  color: #0f172a;
  margin: 0 0 8px;
}
.hero p {
  font-size: 16px;
  color: #64748b;
  margin: 0;
}
</style>
