declare type Ai = any;
declare type VectorizeIndex = any;
declare type R2Bucket = any;
