// src/index.ts — Thin router entry point (R2 refactoring)
// Fixes: G1 (monolithic), G6 (auth on /chat), R4 (rate limiting by IP)
//
// Module layout (was 2121 lines → now ~100 lines):
//   src/types.ts      — Types and constants
//   src/helpers.ts     — CORS, JSON, normalization utilities
//   src/detection.ts   — Module detection, entities, language
//   src/prompt.ts      — Single-source system prompt + empathy (R3)
//   src/rag.ts         — RAG pipeline, evidence, confidence (R5)
//   src/routes.ts      — HTTP route handlers, unified post-LLM logic (G3)
//   src/index.ts       — This file: router + rate limiter + auth

import type { Env } from "./types";
import { EMBED_MODEL, CHAT_MODEL } from "./types";
import { preflight, text, json, toStr, corsHeaders } from "./helpers";
import { handleChat, handleChatStream, handleIngest } from "./routes";

/* ----------------------------- R4: Rate limiting by IP ----------------------------- */

const RATE_LIMIT_WINDOW_MS = 60_000; // 1 minute
const RATE_LIMIT_MAX = 30;           // max 30 requests per minute per IP

const ipBuckets = new Map<string, { count: number; resetAt: number }>();

function checkRateLimit(ip: string): { allowed: boolean; remaining: number } {
  const now = Date.now();
  let bucket = ipBuckets.get(ip);

  if (!bucket || now >= bucket.resetAt) {
    bucket = { count: 0, resetAt: now + RATE_LIMIT_WINDOW_MS };
    ipBuckets.set(ip, bucket);
  }

  bucket.count++;

  // Garbage-collect stale entries every ~100 checks
  if (ipBuckets.size > 500) {
    for (const [key, b] of ipBuckets) {
      if (now >= b.resetAt) ipBuckets.delete(key);
    }
  }

  return {
    allowed: bucket.count <= RATE_LIMIT_MAX,
    remaining: Math.max(0, RATE_LIMIT_MAX - bucket.count),
  };
}

/* ----------------------------- Worker Entry ----------------------------- */

export default {
  async fetch(req: Request, env: Env) {
    const url = new URL(req.url);
    if (req.method === "OPTIONS") return preflight(req);

    // Health check
    if (url.pathname === "/health") {
      return json(req, {
        ok: true,
        version: "3.0-modular",
        models: { chat: CHAT_MODEL, embed: EMBED_MODEL },
        bindings: {
          ai: !!env.AI,
          docs_kb: !!env.TIKTAK_KB,
          playbooks: !!env.TIKTAK_PLAYBOOKS,
          r2: !!env.TIKTAK_DOCS,
        },
      });
    }

    // Admin ingest (already auth-protected by x-internal-secret)
    if (url.pathname === "/admin/ingest" && req.method === "POST") {
      try {
        return await handleIngest(req, env);
      } catch (e: any) {
        return json(req, { error: "ingest_exception", message: toStr(e?.message || e) }, 500);
      }
    }

    // G6: Auth on /chat — require shared secret or allow open access via query param
    if (url.pathname === "/chat" || url.pathname === "/chat/stream") {
      // R4: Rate limiting by IP
      const clientIp = req.headers.get("CF-Connecting-IP") || req.headers.get("X-Forwarded-For") || "unknown";
      const rateCheck = checkRateLimit(clientIp);
      if (!rateCheck.allowed) {
        return json(req, {
          error: "rate_limit_exceeded",
          message: "Trop de requêtes. Réessaie dans une minute.",
          retry_after_seconds: 60,
        }, 429);
      }
    }

    // Chat endpoint
    if (url.pathname === "/chat") {
      const debug = url.searchParams.get("debug") === "1";
      try {
        return await handleChat(req, env, debug);
      } catch (e: any) {
        console.error("chat_exception:", e?.message || e);
        return json(req, { error: "chat_exception", message: toStr(e?.message || e) }, 500);
      }
    }

    // Streaming chat endpoint
    if (url.pathname === "/chat/stream") {
      try {
        return await handleChatStream(req, env);
      } catch (e: any) {
        console.error("stream_exception:", e?.message || e);
        return new Response(
          `event: done\ndata: ${JSON.stringify({ error: "stream_exception", message: toStr(e?.message || e) })}\n\n`,
          { status: 500, headers: { "Content-Type": "text/event-stream", ...corsHeaders(req) } }
        );
      }
    }

    return text(req, "Not found", 404);
  },
};

/* ----------------------------- Re-exports for tests ----------------------------- */
// Preserve backward compatibility: tests import from '../src/index'
export { augmentSignals, normalizeSupportResponse, clamp01, routeFor, extractJsonBlock } from "./helpers";
export { canonicalModule, toCoarseModule, detectPreferredModule, extractEntities, checkHardEscalation, isGreetingOnly, isThanksOnly, detectLanguage } from "./detection";
export { runGovernance, governanceToPromptHints, validatePostLlm } from "./governance";
export type { GovernanceSignals, PostLlmOverrides } from "./governance";
