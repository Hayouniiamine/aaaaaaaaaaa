// src/types.ts — Shared types and constants for the TikTak RAG Worker

export interface Env {
  AI: Ai;
  TIKTAK_KB: VectorizeIndex;
  TIKTAK_PLAYBOOKS: VectorizeIndex;
  TIKTAK_DOCS: R2Bucket;
  INTERNAL_SHARED_SECRET: string;
}

/* ---- Model constants ---- */
export const EMBED_MODEL = "@cf/baai/bge-m3";
export const CHAT_MODEL = "@cf/meta/llama-3.1-8b-instruct-fast";
export const VISION_MODEL = "@cf/meta/llama-3.2-11b-vision-instruct";

/* ---- Conversation types ---- */
export type Role = "user" | "assistant";
export type HistoryMsg = { role: Role; content: string; image_url?: string };

/* ---- Document / Playbook types ---- */
export interface DocChunk {
  tenant_id: string;
  doc_id: string;
  chunk_id: string;
  module: string;
  text: string;
}

export type PlaybookStep =
  | { kind: "ask"; title?: string; question: string; field?: string; options?: string[] }
  | {
      kind: "solve";
      title?: string;
      response: string;
      ui?: {
        label: string;
        route: string;
        highlight?: string;
      };
      common_errors?: string[];
      common_fixes?: string[];
    }
  | { kind: "escalate"; title?: string; reason: string };

export interface Playbook {
  id: string;
  title?: string;
  scope?: string;
  description?: string;
  version?: string;
  triggers?: string[];
  steps: PlaybookStep[];
  common_errors?: Array<{ symptom: string; cause: string; solution: string }>;
  diagnostic_checklist?: any;
  scanner_setup?: Record<string, string>;
  best_practices?: string[];
  related_playbooks?: string[];
}

export interface PlaybookIngestItem {
  tenant_id: string;
  playbook_id: string;
  module: string;
  text: string;
  playbook: Playbook;
}

/* ---- Chat state (multi-turn clarify flows) ---- */
export type ChatState = {
  waiting_for?: "domain" | "error_message" | "order_id" | "screenshot" | null;
  original_question?: string;
  clarify_count?: number;

  /** Assistant-only lightweight state for playbook-guided troubleshooting */
  active_playbook_id?: string | null;
  active_step_index?: number | null;
  collected_entities?: Partial<ExtractedEntities>;
} | null;

/* ---- Retrieval types ---- */
export interface RetrievalContext {
  text: string;
  items: Array<{ id: string; text: string; score: number; module: string }>;
  matches: any[];
  avgScore: number;
  topScore: number;
  playbooks?: Array<{ playbook: Playbook; id: string }>;
}

export type ExtractedEntities = {
  url?: string;
  domain?: string;
  order_id?: string;
  sku_or_product?: string;
  payment_method?: string;
  error_message?: string;
  carrier?: string;
  has_screenshot_mention?: boolean;
  order_refs?: string[];
};

// ---- Governance signals type ----
export interface GovernanceSignals {
  tag?: string;
  tags?: string[];
  matched?: string[];
  http5xx?: boolean;
  siteDown?: boolean;
  emotion?: boolean | {
    score: number;
    triggers: string[];
    sentiment: "frustrated" | "urgent" | "angry" | "calm";
    detected: boolean;
  };
  httpError?: {
    detected: boolean;
    falsePositive: boolean;
    codes: string[];
    reason: string;
    score: number;
  };
  force?: {
    category?: string;
    verdict?: "user_side" | "tiktak_side" | "unclear";
    escalate?: boolean;
    severity?: string;
    ticket_type?: string;
    sentiment?: string;
  };
}
